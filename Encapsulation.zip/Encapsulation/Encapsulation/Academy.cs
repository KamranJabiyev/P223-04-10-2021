﻿using Notification;
using System;
using System.Collections.Generic;
using System.Text;

namespace Encapsulation
{
    public class Academy:Notify
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public int Area { get; set; }
        protected string created;
        private double _price;
        private string description { get; }
        //private readonly string description="init";
        public Academy()
        {
            //MyProperty = 10;
        }
        public Academy(string name,string address,int area,string desc)
        {
            description = desc;
            Name = name;
            Address = address;
            Area = area;
        }
        public double Prise { 
            get 
            {
                if (_price == 0)
                {
                    return -1;
                }
                return _price;
            }
            set 
            {
                if (value < 1000)
                {
                    Console.WriteLine("Price must be more than 1000");
                    return;
                }
                _price = value;
            } 
        }

        //public void SetPrice(double price)
        //{
        //    if (price < 1000)
        //    {
        //        Console.WriteLine("Price must be more than 1000");
        //        return;
        //    }
        //    _price = price;
        //}

        //public double GetPrice()
        //{
        //    if (_price == 0)
        //    {
        //        return -1;
        //    }
        //    return _price;
        //}

        public void Info()
        {
            _price = 4500;
            Name = "Code Academy";
            created = "01.01.2016";
            Console.WriteLine($"{Name} {Address} {Area} {created} {_price} {description}");
        }
    }

}

namespace Encapsulation.Demo2
{
    class Academy
    {

    }
}



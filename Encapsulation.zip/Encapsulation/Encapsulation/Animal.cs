﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Encapsulation.Demo2
{
    class Animal
    {

    }
}

﻿namespace Demo
{
    class Academy
    {
    }

    class Test
    {

    }

    class Test1
    {

    }
}

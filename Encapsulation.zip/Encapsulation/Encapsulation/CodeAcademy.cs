﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Encapsulation
{
    class CodeAcademy:Academy
    {
        public string[] Types;

        public void PrintName()
        {
            
            Info();
            Name = "test";
            created = "02.02.2017";
            Console.WriteLine(created);

        }
    }
}

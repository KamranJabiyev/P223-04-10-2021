﻿using Demo;
using Encapsulation.Demo2;
using Notification;

namespace Encapsulation
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Private Protected - all class members. Private - other assembly, Protected - same assembly
            
            #endregion

            #region Protected Internal - all class members. Protected - other assembly, Internal - same assembly
            //Notify notify = new Notify();
            #endregion

            #region Internal-class(default),all class members
            //Notify n1 = new Notify();
            #endregion

            #region Public -class,all class members. 
            //Academy academy = new Academy();
            //academy.Name = "Main";
            //Console.WriteLine(academy.Name);
            //academy.Info();
            #endregion

            #region Protected - all class members
            //Academy academy = new Academy();
            //academy.Info();
            #endregion

            #region Private - all class members
            //Academy academy = new Academy();
            //typeof(Academy).GetField("_price", BindingFlags.NonPublic | BindingFlags.Instance)
            //    .SetValue(academy, 10000);
            //var _priceAcademy = typeof(Academy)
            //    .GetField("_price", BindingFlags.NonPublic | BindingFlags.Instance)
            //    .GetValue(academy);
            //Console.WriteLine(_priceAcademy);
            #endregion

            #region Encapsulation

            //Academy a1 = new Academy();
            //a1.SetPrice(5500);
            //Console.WriteLine(a1.GetPrice());
            //a1.Prise = 800;
            //Console.WriteLine(a1.Prise);
            #endregion

            #region Readonly - field
            //Academy academy = new Academy("Code","Nizami",1000,"ctor");
            #endregion

            #region Namespace
            //Demo.Academy academy = new Demo.Academy();
            //Test test = new Test();
            //Test1 test1 = new Test1();
            //Encapsulation.Demo2.Academy a1 = new Demo2.Academy();
            //Animal animal = new Animal();
            #endregion
        }
    }
}



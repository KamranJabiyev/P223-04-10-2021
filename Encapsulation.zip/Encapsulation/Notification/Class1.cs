﻿using System;

namespace Notification
{
    public class Notify
    {
        private protected int MyProperty { get; set; }
    }

    class Email : Notify
    {
        public Email()
        {
            MyProperty = 100;
            Notify notify = new Notify();
            //notify.MyProperty = 10;
            //Console.WriteLine(notify.MyProperty);
        }
    }
}

﻿using Notification;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sms
{
    class Message:Notify
    {
    }
}
